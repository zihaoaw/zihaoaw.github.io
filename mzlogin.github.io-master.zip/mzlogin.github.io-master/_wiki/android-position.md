---
layout: wiki
title: 坐标系
cate1: Android
cate2:
description: 坐标系
keywords: Android
---

View 与 MotionEvent 的主要坐标系参考值：

![View Position](/images/wiki/view-position.png)

x、y 和 translationX、translationY 是对于移动过程有用的概念。

1. x = left + translationX

2. y = top + translationY
