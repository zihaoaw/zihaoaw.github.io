---
layout: page
title: 捐助 / Donate
description: 随缘
keywords: Donate
comments: true
menu: 赞助
permalink: /donate/
---

> 做了一些微小的事情，如果对你有帮助，可以考虑请我喝杯咖啡。
> 
> Did some tiny things, consider buying me a cup of coffee if it helps you.

## Paypal

[Donate via Paypal](https://paypal.me/mzlogin)

## 微信 / Wechat

<img style="width:256px;border:1px solid lightgrey;" src="{{ assets_base_url }}/assets/images/receipt-code-wechat.jpeg" alt="wechat receipt code" />

<!-- ## 支付宝 / Alipay -->
<!--  -->
<!-- <img style="width:256px;border:1px solid lightgrey;" src="{{ assets_base_url }}/assets/images/receipt-code-alipay.jpeg" alt="alipay receipt code" /> -->
